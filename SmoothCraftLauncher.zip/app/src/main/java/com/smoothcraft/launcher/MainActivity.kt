package com.smoothcraft.launcher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.smoothcraft.launcher.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.playButton.setOnClickListener {
            // TODO: integrate Minecraft engine bootstrap
        }

        binding.loginButton.setOnClickListener {
            // TODO: launch AuthActivity for Microsoft/Mojang login
        }
    }
}
