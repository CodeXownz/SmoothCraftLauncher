package com.smoothcraft.launcher

import android.content.Context
import java.io.File

object AssetExtractor {
    fun ensureExtracted(ctx: Context) {
        // TODO: Extract OpenJDK and LWJGL files from assets
    }
}
