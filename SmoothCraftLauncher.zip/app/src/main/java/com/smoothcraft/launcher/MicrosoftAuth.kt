package com.smoothcraft.launcher

object MicrosoftAuth {
    // TODO: Implement Microsoft OAuth Device Code flow
}
