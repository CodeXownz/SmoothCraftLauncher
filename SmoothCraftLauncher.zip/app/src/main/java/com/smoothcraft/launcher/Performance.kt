package com.smoothcraft.launcher

object Performance {
    const val PROFILE_BALANCED = "Balanced"
    const val PROFILE_MAX_FPS = "MaxFPS"
    const val PROFILE_BATTERY = "BatterySaver"

    var currentProfile = PROFILE_BALANCED

    val presets: Map<String, Array<String>> = mapOf(
        PROFILE_MAX_FPS to arrayOf("-Xms512m","-Xmx2048m"),
        PROFILE_BATTERY to arrayOf("-Xms256m","-Xmx1024m"),
        PROFILE_BALANCED to arrayOf("-Xms384m","-Xmx1536m")
    )
}
