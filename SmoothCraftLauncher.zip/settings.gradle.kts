rootProject.name = "SmoothCraftLauncher"
include(":app")
